# -*- coding: utf-8 -*-
{
    'name': "my_job_portal",

    'summary': "Short (1 phrase/line) summary of the module's purpose",

    'description': """
Long description of module's purpose
    """,

    'author': "My Company",
    'website': "https://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'hr', 'website'],

    # always loaded
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'security/record_rules.xml',
        'data/mail_template.xml',
        # 'data/server_action.xml',
        'views/menu.xml',
        'views/job_application_views.xml',
        'views/job_position_views.xml',
        'views/template_jobs_list.xml',
        'views/template_job_apply.xml',
        'views/template_sucess.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    'installable':True,
    'application': True,
    'auto_install': False,
}

